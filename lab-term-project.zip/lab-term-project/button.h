#ifndef _BUTTON_H_
#define _BUTTON_H_

#include "mbed.h"

typedef enum {
	NO_EDGE = 0, RISING_EDGE, FALLING_EDGE,
} edge_t;

class Button {
public:
	Button(PinName firstBtnPin, PinName secondBtnPin, PinName thirdBtnPin);
	edge_t detectFirstBtnEdge();
	edge_t detectSecondBtnEdge();
	edge_t detectThirdBtnEdge();

private:
	DigitalIn firstBtn;
	DigitalIn secondBtn;
	DigitalIn thirdBtn;
};

#endif	// _BUTTON_H_