#include "buzzer.h"

Buzzer::Buzzer(PinName pin) : buzzer(pin) {
    note_periods[0] = 3830;
    note_periods[1] = 3400;
    note_periods[2] = 3038;
    note_periods[3] = 2864;
    note_periods[4] = 2550;
    note_periods[5] = 2272;
    note_periods[6] = 2028;
    note_periods[7] = 1912;
    
    addNote[0] = NOTE_b;
    
    saveNote[0] = NOTE_g;
    saveNote[1] = NOTE_a;
	
		openNote[0] = NOTE_g, openNote[1] = NOTE_a, openNote[2] = NOTE_b,
		openNote[3] = NOTE_g, openNote[4] = NOTE_a, openNote[5] = NOTE_b;
		closeNote[0] = NOTE_g, closeNote[1] = NOTE_f, closeNote[2] = NOTE_e, closeNote[3] = NOTE_d;
	
		notNote[0] = NOTE_a;
		notNote[1] = NOTE_a;
}

void Buzzer::playTone(int tone, int duration) {
    buzzer.period_us(note_periods[tone]);
    buzzer = 0.5;
    wait_ms(duration);
    buzzer = 0.0;
}

void Buzzer::playAddNoteMelody() {
    int melcnt = sizeof(addNote) / sizeof(addNote[0]);

    for (int i = 0; i < melcnt; i++) {
        playTone(addNote[i], 100);
        wait_ms(100);
    }

    buzzer = 0;
}

void Buzzer::playSaveNoteMelody() {
    int melcnt = sizeof(saveNote) / sizeof(saveNote[0]);

    for (int i = 0; i < melcnt; i++) {
        playTone(saveNote[i], 200);
        wait_ms(100);
    }

    buzzer = 0;
}

void Buzzer::playOpenNoteMelody(){
	
	int melcnt = sizeof(openNote) / sizeof(openNote[0]);

    for (int i = 0; i < melcnt; i++) {
        playTone(openNote[i], 100);
        wait_ms(100);
    }

    buzzer = 0;
	
}
void Buzzer::playCloseNoteMelody(){
	
	int melcnt = sizeof(closeNote) / sizeof(closeNote[0]);

    for (int i = 0; i < melcnt; i++) {
        playTone(closeNote[i], 100);
        wait_ms(100);
    }

    buzzer = 0;
	
}

void Buzzer::playNotNoteMelody(){
	int melcnt = sizeof(notNote) / sizeof(notNote[0]);
	
	for (int i = 0; i < melcnt; i++) {
        playTone(closeNote[i], 100);
        wait_ms(100);
    }
	
  buzzer = 0;
}