#ifndef _BUZZER_H_
#define _BUZZER_H_

#include "mbed.h"

#define NOTE_c		0
#define NOTE_d		1
#define NOTE_e		2
#define NOTE_f		3
#define NOTE_g		4
#define NOTE_a		5
#define NOTE_b		6
#define NOTE_C		7

class Buzzer {
public:
    Buzzer(PinName pin);
    void playTone(int tone, int duration);
		void playAddNoteMelody();
    void playSaveNoteMelody();
		void playOpenNoteMelody();
		void playCloseNoteMelody();
		void playNotNoteMelody();
private:
    PwmOut buzzer;
    int note_periods[8];
    int addNote[1];
    int saveNote[2];
		int openNote[6];
		int closeNote[4];
		int notNote[2];
};

#endif	// _BUZZER_H_