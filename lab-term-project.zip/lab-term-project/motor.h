#ifndef _MOTOR_H_
#define _MOTOR_H_
#include "mbed.h"

class Motor{
	
	public:
	
	Motor(PinName pwm, PinName dir);
	void forward(double speed);
	void backward(double speed);
	void stop();
	
	private:
	
	PwmOut _pwm;
	DigitalOut _dir;
	int _sign;
	
	
		
	
};

#endif	// _MOTOR_H_