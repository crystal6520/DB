#include "button.h"

Button::Button(PinName firstBtnPin, PinName secondBtnPin, PinName thirdBtnPin)
 : firstBtn(firstBtnPin), secondBtn(secondBtnPin), thirdBtn(thirdBtnPin) {}

edge_t Button::detectFirstBtnEdge() {
	static int fPrevState = 1;

	edge_t edge = NO_EDGE;

	int currState = firstBtn;
	if (currState != fPrevState) {
		wait_ms(10); // debouncing delay
		currState = firstBtn;
		if (currState != fPrevState) {
			if (currState == 1)
				edge = RISING_EDGE;
			else
				edge = FALLING_EDGE;
			fPrevState = currState;
		}
	}

	return edge;
}

edge_t Button::detectSecondBtnEdge() {
	static int sPrevState = 1;

	edge_t edge = NO_EDGE;

	int currState = secondBtn;
	if (currState != sPrevState) {
		wait_ms(10); // debouncing delay
		currState = secondBtn;
		if (currState != sPrevState) {
			if (currState == 1)
				edge = RISING_EDGE;
			else
				edge = FALLING_EDGE;
			sPrevState = currState;
		}
	}

	return edge;
}

edge_t Button::detectThirdBtnEdge() {
	static int sPrevState = 1;

	edge_t edge = NO_EDGE;

	int currState = thirdBtn;
	if (currState != sPrevState) {
		wait_ms(10); // debouncing delay
		currState = thirdBtn;
		if (currState != sPrevState) {
			if (currState == 1)
				edge = RISING_EDGE;
			else
				edge = FALLING_EDGE;
			sPrevState = currState;
		}
	}

	return edge;
}