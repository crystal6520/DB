#include "mbed.h"
#include "button.h"
#include "buzzer.h"
#include "DHT22.h"
#include "motor.h"
#include "Adafruit_GFX/Adafruit_SSD1306.h"

#define NOTE_c_HALF_PERIOD		1915

I2C i2cMaster (I2C_SDA, I2C_SCL);
Adafruit_SSD1306_I2c oled(i2cMaster, D13, 0x78, 64, 128);
DHT22 dht(PB_2);
PwmOut buzzer(PC_9);
Buzzer buzzerModule(PC_9);
Button btn(PA_14, PB_7, PC_4);
Motor motorA(PA_7, PC_8);


Timeout autoCloseTmr;

Serial pc(USBTX, USBRX, 9600);

int input[4] = {0, 0, 0, 0};
int data = 0;
int cnt = 0;
bool doorState = false;

int textSize = 1;
float t = 0.0, h = 0.0;

int password[4] = {1, 2, 3, 4};


void resetInput(){
	for(int i = 0; i < 4; i++){
		input[i] = 0;
	}
	cnt = 0;
}
void processFirstButton() {
	if (btn.detectFirstBtnEdge() == FALLING_EDGE) {
		
		buzzerModule.playAddNoteMelody();
		if (data >= 9) {
			data = 0;
		} else data++;
	}
}

void processSecondButton() {
	if (btn.detectSecondBtnEdge() == FALLING_EDGE) {
		
	buzzerModule.playSaveNoteMelody();
	input[cnt] = data;
	data = 0;
	if(cnt >= 3){
		cnt = 0;
	} else cnt++;
	
	}
}



void doorClose(){
	doorState = false;
	buzzerModule.playCloseNoteMelody();
	motorA.backward(0.5);
	doorState = false;
	pc.printf("Close!\n");
	wait(1.0); 
	motorA.stop();
	
}

void doorOpen(){
	doorState = true;
	buzzerModule.playOpenNoteMelody();
	motorA.forward(0.5);
	doorState = true;
	pc.printf("Open!\n");
	wait(1.0); 
	motorA.stop();
	resetInput();
	autoCloseTmr.attach(&doorClose, 30);
}


void checkPassword(){
	int ckPassword = 0;
	for(int i=0;i<4;i++){
		if(password[i] == input[i]){
			ckPassword++;
		} else {
			ckPassword--;
		}
	}
	if(ckPassword == 4){
			doorOpen();
		} else {
			buzzerModule.playNotNoteMelody();
			resetInput();
		}
}

void processThirdButton() {
	if (btn.detectThirdBtnEdge() == FALLING_EDGE) {
		checkPassword();
		
	}
}

void setup() {
	i2cMaster.frequency(400000);
	
	textSize = 2;
	oled.setTextSize(textSize);
	
	wait(1.0);
	oled.clearDisplay();
	
	buzzer.period_us(NOTE_c_HALF_PERIOD * 2);
	buzzer = 0;
}

int main() {
	setup();

	while (1) {
		processFirstButton();
		processSecondButton();
		processThirdButton();

		pc.printf("%d    %d    %d  %d  %d  %d\n", data, cnt, input[0], input[1], input[2],input[3]);

		oled.clearDisplay();
		oled.setTextCursor(0,0);
		oled.setTextSize(1);		
		if(dht.sample()){
				t = dht.getTemperature() / 10.0;
				h = dht.getHumidity() / 10.0;
		}
		oled.printf("Temp > %0.1f\r\n",t);
		oled.printf("Humdity > %0.1f\r\n",h);
		oled.printf("Door > %s\r\n",doorState?"open ":"close");
		oled.printf("=====================");
		
		oled.setTextSize(2);
		oled.setTextCursor(0, 32);	

		for(int i=0;i<4;i++){

			oled.printf("%d",input[i]);	
		}
		
		oled.display();
		
    wait(1.0);
	}
}


